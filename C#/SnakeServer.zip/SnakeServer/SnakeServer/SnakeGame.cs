﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;

namespace SnakeServer
{
    enum FIELD
    {
        SPACE,
        WALL
    }
    enum MOVE
    {
        LEFT,
        RIGHT,
        UP,
        DOWN
    }
    struct Position
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int index { get; set; }

    }

    class Const
    {
        public const int X_SIZE = 70;
        public const int Y_SIZE = 50;
        public const int BASE_SPEED = 1000;
    }
    class SnakeGame
    {
        private static int numberOfUser;
        private Position[] startingPoint;
        //private Snake snake;
        private FIELD[,] gameField;
        private DotData dotData;
        private int score;
        private int speed;
        private int x;
        private bool endFlag;
        private bool pauseFlag;
        private Stopwatch stopwatch;

        public void GameHandler()
        {
            InitUsers();
            InitGame();
            Thread getKeyboardInputThread = new Thread(GetKeyboardInput);
            getKeyboardInputThread.Start();

            while (!endFlag)
            {
                if (!pauseFlag)
                {
                    Thread printMoveThread = new Thread(PrintAndMove);
                    printMoveThread.Start();
                    printMoveThread.Join();
                }
            }
        }

        public void InitUsers()
        {
            numberOfUser = AsynchronousSocketListener.ClientsData.Count();
            startingPoint = new Position[numberOfUser];

            for (int i = 0; i < numberOfUser; i++)
            {
                Position pos = new Position();
                pos.X = (Const.X_SIZE / (numberOfUser + 2)) * (i + 1);
                pos.Y = (Const.Y_SIZE / (numberOfUser + 2)) * (i + 1);

                startingPoint[i] = pos;
            }

            int index = 0;
            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                client.Snake = new Snake(startingPoint[index]);
                index++;

            }

        }

        public bool InitGame()
        {
            stopwatch = new Stopwatch();
            stopwatch.Start();
            endFlag = false;
            pauseFlag = false;
            score = 0;
            x = 1;
            speed = Const.BASE_SPEED / (x * 5);

            MakeAndPrintWall();
            PrintManual();

            // create Dot spawn Area
            dotData = new DotData();
            dotData.CreateDot();

            return true;
        }


        public void MakeAndPrintWall()
        {
            gameField = new FIELD[Const.Y_SIZE, Const.X_SIZE];

            // Create Wall
            for (int y = 0; y < Const.Y_SIZE; y++)
            {
                for (int x = 0; x < Const.X_SIZE; x += 2)
                {
                    if (x == 0 | x == (Const.X_SIZE - 2))
                        gameField[y, x] = FIELD.WALL;
                    if (y == 0 | y == (Const.Y_SIZE - 1))
                        gameField[y, x] = FIELD.WALL;
                }
            }

            // print Field
            for (int x = 0; x < Const.X_SIZE; x += 2)
            {
                for (int y = 0; y < Const.Y_SIZE; y++)
                {
                    if (gameField[y, x] == FIELD.WALL)
                    {
                        Console.SetCursorPosition(x, y);
                        Write("■");
                    }
                }
            }
        }

        public void PrintManual()
        {
            int manualX = Const.X_SIZE + 1;
            int manualY = 10;

            Console.SetCursorPosition(manualX, manualY++);
            Write("MOVE  : ←↑↓→");
            Console.SetCursorPosition(manualX, manualY++);
            Write("Space : pause");
            Console.SetCursorPosition(manualX, manualY++);
            Write("Z, X  : Speed Control");
            Console.SetCursorPosition(manualX, manualY++);
            Write("Enter : Restart Game");

            manualY += 5;
            Console.SetCursorPosition(manualX, manualY++);
            Write("----DEBUG CONTROL----");
            Console.SetCursorPosition(manualX, manualY++);
            Write("+ : Add Length ");
            Console.SetCursorPosition(manualX, manualY++);
            Write("- : Sub Length ");


        }


        public void PrintAndMove()
        {
            PrintScreen();
            MoveSnake();
            Thread.Sleep(speed);
        }

        public void PrintScreen()
        {
            // print score
            Console.SetCursorPosition(Const.X_SIZE + 1, 0);
            Write($"Score : {score}");

            // print time
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            stopwatch.Start();
            Console.SetCursorPosition(Const.X_SIZE + 1, 1);
            Write($"Time  : {ts.Seconds}");

            // print x1,x2,x3...
            Console.SetCursorPosition(Const.X_SIZE + 1, 2);
            Write($"배속  : x{x}");


            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                Snake snake = client.Snake;
                int snakeLen = snake.SnakeLength;

                Console.SetCursorPosition(snake.SnakePos[0].X, snake.SnakePos[0].Y);
                Write("□");
                Console.SetCursorPosition(snake.SnakePos[snakeLen].X, snake.SnakePos[snakeLen].Y);
                Write("  ");

                Console.SetCursorPosition(snake.SnakePos[0].X, snake.SnakePos[0].Y);
            }

            SnakePosSend();

        }

        public void SnakePosSend()
        {

            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                foreach (ClientData clientData in AsynchronousSocketListener.ClientsData)
                {
                    Snake snake = clientData.Snake;
                    string clientSankePosData = "";
                    clientSankePosData += ((IPEndPoint)clientData.Client.RemoteEndPoint).ToString() + " " + clientData.Snake.SnakeLength + " ";
                    for (int i = 0; i < snake.SnakeLength + 1; i++)
                    {
                        clientSankePosData += String.Format("{0},{1} ", snake.SnakePos[i].X, snake.SnakePos[i].Y);
                    }
                    AsynchronousSocketListener.Send(client.Client, 'p', clientSankePosData);
                }



                //Snake snake = client.Snake;
                //string clientSankePosData = "";
                //clientSankePosData += ((IPEndPoint)client.Client.RemoteEndPoint).ToString() + " ";
                //for (int i = 0; i < snake.SnakeLength + 1 ; i++)
                //{
                //    clientSankePosData += String.Format("{0},{1} ", snake.SnakePos[i].X, snake.SnakePos[i].Y);
                //}
                //AsynchronousSocketListener.Send(client.Client,'p',clientSankePosData);
            }

        }
        

        public void MoveSnake()
        {
            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                Snake snake = client.Snake;
                int snakeLen = snake.SnakeLength;

                for (int i = snake.SnakeLength - 1; i >= 0; i--)
                {
                    snake.SnakePos[i + 1] = snake.SnakePos[i];
                }

                switch (snake.SnakeMoveDirection)
                {
                    case MOVE.LEFT:
                        snake.SnakePos[0].X -= 2;
                        break;
                    case MOVE.RIGHT:
                        snake.SnakePos[0].X += 2;
                        break;
                    case MOVE.UP:
                        snake.SnakePos[0].Y -= 1;
                        break;
                    case MOVE.DOWN:
                        snake.SnakePos[0].Y += 1;
                        break;
                    default:
                        break;
                }

                if (IsCollision(snake))
                    endFlag = true;
                else
                {
                    dotData.AreaBan(snake);
                    dotData.AreaFree(snake);
                }
            }
        }

        public bool IsCollision(Snake snake)
        {
            Position snakeHead = snake.SnakePos[0];

            if (snakeHead.X == 0 || snakeHead.X == (Const.X_SIZE - 2))
                return true;
            else if (snakeHead.Y == 0 || snakeHead.Y == (Const.Y_SIZE - 1))
                return true;

            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                Snake EnemySnake = client.Snake;
                int snakeLen = EnemySnake.SnakeLength;

                for (int i = 0; i <= EnemySnake.SnakeLength; i++)
                {
                    // 적대가리가 자신의 대가리 일때는 넘긴다.
                    if (i == 0 && System.Object.Equals(snake, EnemySnake))
                        continue;

                    if (snakeHead.X == EnemySnake.SnakePos[i].X && (snakeHead.Y == EnemySnake.SnakePos[i].Y))
                    {
                        return true;
                    }
                }

            }

            if (System.Object.Equals(snakeHead, dotData.Dot))
            {
                snake.SnakeLength++;
                score += 1000;
                dotData.CreateDot();
            }

            return false;
        }

        public void GetKeyboardInput()
        {
            while (!endFlag)
            {
                ConsoleKeyInfo keys;
                if (Console.KeyAvailable)
                {
                    keys = Console.ReadKey(true);

                    foreach (ClientData client in AsynchronousSocketListener.ClientsData)
                    {
                        Snake snake = client.Snake;
                        int snakeLen = snake.SnakeLength;

                        switch (keys.Key)
                        {
                            case ConsoleKey.UpArrow:
                                if (snake.SnakeMoveDirection != MOVE.DOWN)
                                    snake.SnakeMoveDirection = MOVE.UP;
                                break;
                            case ConsoleKey.DownArrow:
                                if (snake.SnakeMoveDirection != MOVE.UP)
                                    snake.SnakeMoveDirection = MOVE.DOWN;
                                break;
                            case ConsoleKey.LeftArrow:
                                if (snake.SnakeMoveDirection != MOVE.RIGHT)
                                    snake.SnakeMoveDirection = MOVE.LEFT;
                                break;
                            case ConsoleKey.RightArrow:
                                if (snake.SnakeMoveDirection != MOVE.LEFT)
                                    snake.SnakeMoveDirection = MOVE.RIGHT;
                                break;
                            case ConsoleKey.Add:
                                snake.SnakeLength++;
                                dotData.NumberOfArea--;
                                break;
                            case ConsoleKey.Subtract:
                                snake.SnakeLength--;
                                break;
                            case ConsoleKey.Spacebar:
                                if (!pauseFlag)
                                {
                                    pauseFlag = !pauseFlag;
                                    stopwatch.Stop();
                                }
                                else
                                {
                                    pauseFlag = !pauseFlag;
                                    stopwatch.Start();
                                }
                                break;
                            case ConsoleKey.Enter:
                                endFlag = true;
                                break;
                            case ConsoleKey.Z:
                                x--;
                                if (x < 1)
                                    x = 1;
                                speed = Const.BASE_SPEED / (x * 5);
                                break;
                            case ConsoleKey.X:
                                x++;
                                if (x > 5)
                                    x = 5;
                                speed = Const.BASE_SPEED / (x * 5);
                                break;

                            default:
                                break;
                        }
                    }
                }
                Thread.Sleep(20);
            }
        }
    }
}
