﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace SnakeServer
{
    class DotData
    {
        private Position[] spawnDotArea;
        private int numberOfArea;
        private int endPoint;
        private Position dot;

        public DotData()
        {
            spawnDotArea = new Position[(Const.X_SIZE - 4) / 2 * (Const.Y_SIZE - 2) + 1];
            numberOfArea = 0;
            for (int y = 1; y < (Const.Y_SIZE - 1); y++)
            {
                for (int x = 2; x < (Const.X_SIZE - 2); x += 2)
                {
                    Position pos = new Position();
                    pos.X = x;
                    pos.Y = y;
                    pos.index = numberOfArea;
                    spawnDotArea[numberOfArea++] = pos;
                }
            }
            endPoint = numberOfArea - 1;
        }

        public int NumberOfArea { get => numberOfArea; set => numberOfArea = value; }
        internal Position[] SpawnDotArea { get => spawnDotArea; set => spawnDotArea = value; }
        internal Position Dot { get => dot; set => dot = value; }

        public void AreaBan(Snake snake)
        {
            for (int i = 0; i < snake.SnakeLength; i++)
            {
                int index = (snake.SnakePos[i].Y - 1) * (Const.X_SIZE / 2 - 2) + (snake.SnakePos[i].X / 2) - 1;
                Position temp = spawnDotArea[index];
                spawnDotArea[index] = spawnDotArea[numberOfArea];
                spawnDotArea[numberOfArea] = temp;
            }
        }

        public void AreaFree(Snake snake)
        {
            int index = spawnDotArea[endPoint].index;
            Position temp = spawnDotArea[index];
            spawnDotArea[index] = spawnDotArea[endPoint];
            spawnDotArea[endPoint] = temp;
        }

        public void CreateDot()
        {
            numberOfArea--;
            Random random = new Random();
            int randomIndex = random.Next(0, numberOfArea - 1);
            dot.X = spawnDotArea[randomIndex].X;
            dot.Y = spawnDotArea[randomIndex].Y;

            Console.SetCursorPosition(dot.X, dot.Y);
            Console.ForegroundColor = ConsoleColor.Green;
            Write("□");
            Console.ForegroundColor = ConsoleColor.White;

            foreach (ClientData client in AsynchronousSocketListener.ClientsData)
            {
                AsynchronousSocketListener.Send(client.Client, 'd', string.Format("{0},{1}", dot.X, dot.Y));
            }

        }
    }
}
