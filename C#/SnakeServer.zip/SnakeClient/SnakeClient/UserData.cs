﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace SnakeClient
{
    public class UserData
    {
        private string userName;
        private Snake snake;

        public UserData(string Name)
        {
            userName = Name;
            snake = new Snake();
        }

        public string UserName { get => userName; set => userName = value; }
        internal Snake Snake { get => snake; set => snake = value; }

        public void UpdatePos()
        {

        }

    }

    public class UserDataHandler
    {
        public static List<UserData> userDatas = new List<UserData>();

        public static void UpdateUserPos(string[] posData)
        {
            string userName = posData[0];

            UserData user = userDatas.Find(x => x.UserName.Contains(userName));

            if (user == null)
            {
                user = new UserData(userName);
                userDatas.Add(user);
            }


            user.Snake.SnakeLength = Int32.Parse(posData[1]);

            for (int i = 0; i < user.Snake.SnakeLength + 1 ; i++)
            {
                string[] pos = posData[i+2].Split(new string[] { "," }, StringSplitOptions.None);
                user.Snake.SnakePos[i].X = Int32.Parse(pos[0]);
                user.Snake.SnakePos[i].Y = Int32.Parse(pos[1]);
            }

            MainApp.clientHandler.PrintScreen();
            
        }


    }
}
