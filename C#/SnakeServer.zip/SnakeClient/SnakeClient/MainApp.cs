﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using static System.Console;
using System.IO;
using System.Threading;

namespace SnakeClient
{
    enum FIELD
    {
        SPACE,
        WALL
    }
    enum MOVE
    {
        LEFT,
        RIGHT,
        UP,
        DOWN
    }
    struct Position
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int index { get; set; }

    }
    class Const
    {
        public const int X_SIZE = 70;
        public const int Y_SIZE = 50;
        public const int BASE_SPEED = 1000;
    }

    class MainApp
    {
        public static bool gameStart = false;
        public static ClientHandler clientHandler = new ClientHandler();
        static void Main(string[] args)
        {
            

            AsynchronousClient.StartClient();
            string msg = "";
            while (!gameStart)
            {
                if (msg !="r" && msg != "R")
                {
                    msg = ReadLine();
                    AsynchronousClient.Send(AsynchronousClient.Mainclient, 's', msg);
                }
                
            }

            //서버로부터 유저수, 유저의 스타트 지점을 받아오는 메소드 추가.

            //ClientHandler clientHandler = new ClientHandler();
            try
            {
                Clear();
                clientHandler.HandlerInit();


                while (true)
                {
                    

                }
                
            }
            catch (Exception)
            {
                WriteLine("오류 발생");
                throw;
            }
            



        }

    }
}
