﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeClient
{
    class Snake
    {
        private Position[] snakePos;
        private int snakeLength;
        private MOVE snakeMoveDirection;

        public Snake()
        {
            snakePos = new Position[(Const.X_SIZE - 4) / 2 * (Const.Y_SIZE - 2)];
            
            // Snake Start Point.
            snakePos[0].Y = Const.Y_SIZE / 2;
            snakePos[0].X = Const.X_SIZE / 2;
            if (snakePos[0].X % 2 != 0)
                snakePos[0].X += 1;

            // 기존 디폴트 값은 0,0이므로 벽 위치랑 중복되므로 벽이 지워진다. 맵 구성요소에 영향을 미치지 않는 영역 값을 넣아준다.
            for (int i = 1; i < (Const.X_SIZE - 4) / 2 * (Const.Y_SIZE - 2); i++)
            {
                snakePos[i].Y = Const.Y_SIZE - 1;
                snakePos[i].X = Const.X_SIZE;
            }

            snakeLength = 1;
            snakeMoveDirection = MOVE.RIGHT;
        }

        public Snake(Position startPos)
        {
            snakePos = new Position[(Const.X_SIZE - 4) / 2 * (Const.Y_SIZE - 2)];

            // Snake Start Point.
            snakePos[0].Y = startPos.Y;
            snakePos[0].X = startPos.X;
            if (snakePos[0].X % 2 != 0)
                snakePos[0].X += 1;

            // 기존 디폴트 값은 0,0이므로 벽 위치랑 중복되므로 벽이 지워진다. 맵 구성요소에 영향을 미치지 않는 영역 값을 넣아준다.
            for (int i = 1; i < (Const.X_SIZE - 4) / 2 * (Const.Y_SIZE - 2); i++)
            {
                snakePos[i].Y = Const.Y_SIZE - 1;
                snakePos[i].X = Const.X_SIZE;
            }

            snakeLength = 1;
            snakeMoveDirection = MOVE.RIGHT;
        }

        public int SnakeLength { get => snakeLength; set => snakeLength = value; }
        internal MOVE SnakeMoveDirection { get => snakeMoveDirection; set => snakeMoveDirection = value; }
        internal Position[] SnakePos { get => snakePos; set => snakePos = value; }
    }
}
